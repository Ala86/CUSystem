﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
namespace TclassLibrary
{
    public partial class fixrbal : Form
    {
        string cs = string.Empty;
        int ncompid = 0;
        string dloca = string.Empty;

        DataTable acctview = new DataTable();
        DataTable transview = new DataTable();
        DataTable runbalview = new DataTable();
        DataTable fixbalview = new DataTable();
        DataTable bkbalview = new DataTable();
        decimal gnRunBal = 0.00m;
        decimal gnBookBal = 0.00m;
        bool glMultipleSelection = false;

        updateDailyBalance udb = new updateDailyBalance();
        //public class updateDailyBalance
        //{
        //    public void updDayBal(string cs, DateTime dTrandate, string dacct, decimal ntranAmt, int branid, int compid)

        public fixrbal(string tcCos, int tnCompid, string tcLoca, DateTime tdSysDate, string tcUserID, int tnBranchid)
        {
            InitializeComponent();
            cs = tcCos;
            ncompid = tnCompid;
            dloca = tcLoca;
        }


        private void fixrbal_Load(object sender, EventArgs e)
        {
            this.Text = dloca + "<< Running Balance Check >>";
        }
        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Down || e.KeyCode == Keys.Tab)
            {
                SelectNextControl(ActiveControl, true, true, true, true);
                e.Handled = true;
                AllClear2Go();
            }
            else if (e.KeyCode == Keys.Up)
            {
                SelectNextControl(ActiveControl, false, true, true, true);
                e.Handled = true;
                AllClear2Go();
            }
        }

        #region Checking if all the mandatory conditions are satisfied
        private void AllClear2Go()
        {
            if ((radioButton1.Checked && maskedTextBox1.Text!="")||glMultipleSelection)
            {
                saveButton.Enabled = true;
                saveButton.BackColor = Color.LawnGreen;
                saveButton.Select();
            }
            else
            {
                saveButton.Enabled = false;
                saveButton.BackColor = Color.Gainsboro;
            }
        }
        #endregion 
        private void saveButton_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                fixRunBal(maskedTextBox1.Text, Convert.ToDecimal(textBox4.Text),true);
                MessageBox.Show("Running Balance fix successful");
                radioButton1.Checked = radioButton2.Checked = radioButton3.Checked = radioButton4.Checked = false;
                textBox1.Text = textBox2.Text = textBox4.Text = textBox5.Text = textBox6.Text =  maskedTextBox1.Text = "";
                saveButton.Enabled = false;
                saveButton.BackColor = Color.Gainsboro;
            }
            else
            {
                fixRunBal("",0.00m, false);
            }
            progressBar1.Value = 0; 
        }

//        private void getAccounts(string tcquery)
//        {
//            transview.Clear();
//            using (SqlConnection ndConnHandle = new SqlConnection(cs))
//            {
//                ndConnHandle.Open();
//                SqlDataAdapter da1 = new SqlDataAdapter(tcquery, ndConnHandle);
//                da1.Fill(transview);
//                if (transview != null && transview.Rows.Count > 0)
//                {
//                    string tcAcct = string.Empty;
//         //           decimal tnBookBal = 0.00m;
//                    int dcount = 0;
//                    int j = 0;
//                    int transcount = transview.Rows.Count;
//                   foreach (DataRow drow in transview.Rows)
//                    {
//                        tcAcct = drow["cacctnumb"].ToString();
//                        textBox5.Text = tcAcct;
////                        tnBookBal = Convert.ToDecimal(drow["nbookbal"]);
//                        dcount++;
//                        j = dcount + 1;
//                        progressBar1.Value = j * progressBar1.Maximum / transcount;
//                        getBookBal(tcAcct);
//                        getRunBal(tcAcct);
//                        if(gnBookBal != gnRunBal)
//                        {
//                            fixRunBal(tcAcct, gnBookBal, false);
//                        }
//                    }
//                    saveButton.Enabled = false;
//                    saveButton.BackColor = Color.Gainsboro;
//                    progressBar1.Value = 0;
//                    radioButton1.Checked = radioButton2.Checked = radioButton3.Checked = radioButton4.Checked = false;
//                    MessageBox.Show("Running Balance fix successful");
//                }
//            }
//        }

        private void getBookBal(string tcAcct)
        {
            bkbalview.Clear();
            string sqlString0 = "select nbookbal= case when sum(tranhist.ntranamnt) is not null then sum(ntranamnt) else 0.00 end from tranhist where cacctnumb =  " + "'" + tcAcct + "'";
            using (SqlConnection ndConnHandle = new SqlConnection(cs))
            {
                ndConnHandle.Open();
                SqlDataAdapter dam0 = new SqlDataAdapter(sqlString0, ndConnHandle);
                dam0.Fill(bkbalview);
                if (bkbalview != null && bkbalview.Rows.Count > 0)
                {
                    gnBookBal = Convert.ToDecimal(bkbalview.Rows[0]["nbookbal"]);// bkbalview.Rows[0]["nbookbal"].ToString().Trim()!="null" ? Convert.ToDecimal(bkbalview.Rows[0]["nbookbal"]) : 0.00m;
                    updateBkBal(tcAcct, gnBookBal);
                }
            }
        }

        private void getRunBal(string tcAcctNo)
        {
            runbalview.Clear();
            string runbalsql0 = "select nnewbal, cstack from tranhist where cacctnumb  = " + "'"+tcAcctNo +"'"+ " order by cstack desc ";
            using (SqlConnection ndConnHandle = new SqlConnection(cs))
            {
                ndConnHandle.Open();
                SqlDataAdapter darunsql0 = new SqlDataAdapter(runbalsql0, ndConnHandle);
                darunsql0.Fill(runbalview);
                if (runbalview != null && runbalview.Rows.Count > 0)
                {
                    object val = runbalview.Rows[0]["nnewbal"];
                    string valtype = val.GetType().ToString();
                    if(valtype != "System.Decimal")
                    {
                        MessageBox.Show("The culprit is " + val);
                    }
                    else
                    {
                        gnRunBal = Convert.ToDecimal(runbalview.Rows[0]["nnewbal"]);
                    }
                }
            }
        }

        private void updateBkBal(string tcAct, decimal tnBkBal)
        {
            using (SqlConnection ndConnHandle1 = new SqlConnection(cs))
            {
                string cqueryb = "update glmast set nbookbal = @tnBkBal where cacctnumb=@tcAcctNumb";
                SqlDataAdapter cuscommand = new SqlDataAdapter();
                cuscommand.UpdateCommand = new SqlCommand(cqueryb, ndConnHandle1);
                cuscommand.UpdateCommand.Parameters.Add("@tnBkBal", SqlDbType.Decimal).Value = tnBkBal;
                cuscommand.UpdateCommand.Parameters.Add("@tcAcctNumb", SqlDbType.VarChar).Value = tcAct; 

                ndConnHandle1.Open();
                cuscommand.UpdateCommand.ExecuteNonQuery();
                ndConnHandle1.Close();
            }
        }


        private void fixRunBal(string tcfAcct, decimal tnfBkBal, bool act)
        {
            if (act)
            {
                if (MessageBox.Show("Have you ensured that the book balance is correct and would like to continue", "Running Balance Fix Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    string sqlString = "select cacctnumb,ntranamnt,dtrandate,itemid, cstack from tranhist where cacctnumb = " + "'" + tcfAcct + "'" + " and ctrancode <> '13' order by itemid desc";
                    fixbalview.Clear();
                    using (SqlConnection ndConnHandle = new SqlConnection(cs))
                    {
                        ndConnHandle.Open();
                        SqlDataAdapter dam = new SqlDataAdapter(sqlString, ndConnHandle);
                        dam.Fill(fixbalview);
                        if (fixbalview != null && fixbalview.Rows.Count > 0)
                        {
                            int j = 1;
                            int transcount = fixbalview.Rows.Count;
                            for (int k = 0; k < fixbalview.Rows.Count; k++)
                            {
                                int lnItemid = Convert.ToInt32(fixbalview.Rows[k]["itemid"]);
                                progressBar1.Value = j * progressBar1.Maximum / transcount;
                                decimal lnTranAmt = Convert.ToDecimal(fixbalview.Rows[k]["ntranamnt"]);
                                updateTrans(tcfAcct, tnfBkBal, lnItemid);
                                tnfBkBal = tnfBkBal - lnTranAmt;
                                j++;
                            }
                        }
                    }
                }
            }
            else
            {
                string sqlString0 = string.Empty;
                string sqlString1 = string.Empty;
                string lcAcct = string.Empty;
                decimal lnBookBal = 0.00m;
                string lcStack = string.Empty;
                int lnItemid = 0;
                decimal lnTranAmt = 0.00m;
                DateTime ldTranDate = new DateTime();
                int lnSelect = (radioButton3.Checked ? 1 : (radioButton4.Checked ? 2 : (radioButton5.Checked ? 3 : 4)));
                //                string sqlString = "select cacctnumb,ntranamnt,cstack from tranhist where cacctnumb = " + "'" + tcfAcct + "'" + " and ctrancode <> '13' order by cstack desc";
                switch (lnSelect)
                {
                    case 1: //loan accounts 
                        sqlString0 = "select cacctnumb,cacctname,nbookbal from glmast where intcode = 0 and acode in ('130','131') order by cacctnumb";
                        using (SqlConnection ndConnHandle = new SqlConnection(cs))
                        {
                            ndConnHandle.Open();
                            SqlDataAdapter intAcct = new SqlDataAdapter(sqlString0, ndConnHandle);
                            DataTable intAcctView = new DataTable();
                            intAcct.Fill(intAcctView);
                            if (intAcctView.Rows.Count > 0)
                            {
                                int j = 1;
                                int n = 0;
                                int transcount = intAcctView.Rows.Count;
                                int indCount = 0;
                                textBox1.Text = j.ToString().Trim();
                                textBox2.Text = transcount.ToString().Trim();
                                for (int m = 0; m < intAcctView.Rows.Count; m++)
                                {
                                    n = m + 1;
                                    textBox1.Text = m.ToString().Trim();
                                    progressBar1.Value = j * progressBar1.Maximum / transcount;
                                    lcAcct = Convert.ToString(intAcctView.Rows[m]["cacctnumb"]);
                                    lnBookBal = Convert.ToDecimal(intAcctView.Rows[m]["nbookbal"]);
                                    maskedTextBox1.Text = lcAcct;
                                    textBox5.Text = Convert.ToString(intAcctView.Rows[m]["cacctname"]).Trim();
                                    textBox4.Text = lnBookBal.ToString("N2");
                                    sqlString1 = "select cacctnumb,ntranamnt,dtrandate,itemid, cstack from tranhist where cacctnumb = " + "'" + lcAcct + "'" + " order by itemid desc";
                                    SqlDataAdapter dan = new SqlDataAdapter(sqlString1, ndConnHandle);
                                    DataTable balview = new DataTable();
                                    dan.Fill(balview);
                                    if (balview.Rows.Count > 0)
                                    {
                                        indCount = balview.Rows.Count;
                                        for (int l = 0; l < indCount; l++)
                                        {
                                            lnItemid = Convert.ToInt32(balview.Rows[l]["itemid"]);
                                            lnTranAmt = Convert.ToDecimal(balview.Rows[l]["ntranamnt"]);
                                            ldTranDate = Convert.ToDateTime(balview.Rows[l]["dtrandate"]);
                                            updateTrans(lcAcct, lnBookBal, lnItemid);
                                            //                                            udb.updDayBal(cs, ldTranDate, lcAcct, lnTranAmt, globalvar.gnBranchid, ncompid);
                                            lnBookBal = lnBookBal - lnTranAmt;
                                        }
                                    }//else { MessageBox.Show("No transactions found "); }
                                    j++;
                                }
                            }
                            else { MessageBox.Show("No Loan accounts found "); }
                            MessageBox.Show("Loan Accounts Running Balance fixed successfully ");
                        }
                        break;
                    case 2: //Internal accounts 
                        sqlString0 = "select cacctnumb,cacctname,nbookbal from glmast where intcode = 1 order by cacctnumb";
                        using (SqlConnection ndConnHandle = new SqlConnection(cs))
                        {
                            ndConnHandle.Open();
                            SqlDataAdapter intAcct = new SqlDataAdapter(sqlString0, ndConnHandle);
                            DataTable intAcctView = new DataTable();
                            intAcct.Fill(intAcctView);
                            if (intAcctView.Rows.Count > 0)
                            {
                                int j = 1;
                                int n = 0;
                                int transcount = intAcctView.Rows.Count;
                                int indCount = 0;
                                textBox1.Text = j.ToString().Trim();
                                textBox2.Text = transcount.ToString().Trim();
                                for (int m = 0; m < intAcctView.Rows.Count; m++)
                                {
                                    n = m + 1;
                                    textBox1.Text = m.ToString().Trim();
                                    progressBar1.Value = j * progressBar1.Maximum / transcount;
                                    lcAcct = Convert.ToString(intAcctView.Rows[m]["cacctnumb"]);
                                    lnBookBal = Convert.ToDecimal(intAcctView.Rows[m]["nbookbal"]);
                                    maskedTextBox1.Text = lcAcct;
                                    textBox5.Text = Convert.ToString(intAcctView.Rows[m]["cacctname"]).Trim();
                                    textBox4.Text = lnBookBal.ToString("N2");
                                    sqlString1 = "select cacctnumb,ntranamnt,dtrandate,itemid, cstack from tranhist where cacctnumb = " + "'" + lcAcct + "'" + " order by itemid desc";
                                    SqlDataAdapter dan = new SqlDataAdapter(sqlString1, ndConnHandle);
                                    DataTable balview = new DataTable();
                                    dan.Fill(balview);
                                    if (balview.Rows.Count > 0)
                                    {
                                        indCount = balview.Rows.Count;
                                        for (int l = 0; l < indCount; l++)
                                        {
                                            lnItemid = Convert.ToInt32(balview.Rows[l]["itemid"]);
                                            lnTranAmt = Convert.ToDecimal(balview.Rows[l]["ntranamnt"]);
                                            ldTranDate = Convert.ToDateTime(balview.Rows[l]["dtrandate"]);
                                            updateTrans(lcAcct, lnBookBal, lnItemid);
//                                            udb.updDayBal(cs, ldTranDate, lcAcct, lnTranAmt, globalvar.gnBranchid, ncompid);
                                            lnBookBal = lnBookBal - lnTranAmt;
                                        }
                                    }//else { MessageBox.Show("No transactions found "); }
                                    j++;
                                }
                            }
                            else { MessageBox.Show("No internal accounts found "); }
                            MessageBox.Show("Internal Accounts Running Balance fixed successfully ");
                        }
                        break;
                    case 3: //shares accounts 
                        sqlString0 = "select cacctnumb,cacctname,nbookbal from glmast where intcode = 0 and acode in ('270','271') order by cacctnumb";
                        using (SqlConnection ndConnHandle = new SqlConnection(cs))
                        {
                            ndConnHandle.Open();
                            SqlDataAdapter intAcct = new SqlDataAdapter(sqlString0, ndConnHandle);
                            DataTable intAcctView = new DataTable();
                            intAcct.Fill(intAcctView);
                            if (intAcctView.Rows.Count > 0)
                            {
                                int j = 1;
                                int n = 0;
                                int transcount = intAcctView.Rows.Count;
                                int indCount = 0;
                                textBox1.Text = j.ToString().Trim();
                                textBox2.Text = transcount.ToString().Trim();
                                for (int m = 0; m < intAcctView.Rows.Count; m++)
                                {
                                    n = m + 1;
                                    textBox1.Text = m.ToString().Trim();
                                    progressBar1.Value = j * progressBar1.Maximum / transcount;
                                    lcAcct = Convert.ToString(intAcctView.Rows[m]["cacctnumb"]);
                                    lnBookBal = Convert.ToDecimal(intAcctView.Rows[m]["nbookbal"]);
                                    maskedTextBox1.Text = lcAcct;
                                    textBox5.Text = Convert.ToString(intAcctView.Rows[m]["cacctname"]).Trim();
                                    textBox4.Text = lnBookBal.ToString("N2");
                                    sqlString1 = "select cacctnumb,ntranamnt,dtrandate,itemid, cstack from tranhist where cacctnumb = " + "'" + lcAcct + "'" + " order by itemid desc";
                                    SqlDataAdapter dan = new SqlDataAdapter(sqlString1, ndConnHandle);
                                    DataTable balview = new DataTable();
                                    dan.Fill(balview);
                                    if (balview.Rows.Count > 0)
                                    {
                                        indCount = balview.Rows.Count;
                                        for (int l = 0; l < indCount; l++)
                                        {
                                            lnItemid = Convert.ToInt32(balview.Rows[l]["itemid"]);
                                            lnTranAmt = Convert.ToDecimal(balview.Rows[l]["ntranamnt"]);
                                            ldTranDate = Convert.ToDateTime(balview.Rows[l]["dtrandate"]);
                                            updateTrans(lcAcct, lnBookBal, lnItemid);
                                            //                                            udb.updDayBal(cs, ldTranDate, lcAcct, lnTranAmt, globalvar.gnBranchid, ncompid);
                                            lnBookBal = lnBookBal - lnTranAmt;
                                        }
                                    }//else { MessageBox.Show("No transactions found "); }
                                    j++;
                                }
                            }
                            else { MessageBox.Show("No share accounts found "); }
                            MessageBox.Show("Share Accounts Running Balance fixed successfully ");
                        }
                        break;
                    case 4: //Savings accounts 
                        sqlString0 = "select cacctnumb,cacctname,nbookbal from glmast where intcode = 0 and acode in ('250','251') order by cacctnumb";
                        using (SqlConnection ndConnHandle = new SqlConnection(cs))
                        {
                            ndConnHandle.Open();
                            SqlDataAdapter intAcct = new SqlDataAdapter(sqlString0, ndConnHandle);
                            DataTable intAcctView = new DataTable();
                            intAcct.Fill(intAcctView);
                            if (intAcctView.Rows.Count > 0)
                            {
                                int j = 1;
                                int n = 0;
                                int transcount = intAcctView.Rows.Count;
                                int indCount = 0;
                                textBox1.Text = j.ToString().Trim();
                                textBox2.Text = transcount.ToString().Trim();
                                for (int m = 0; m < intAcctView.Rows.Count; m++)
                                {
                                    n = m + 1;
                                    textBox1.Text = m.ToString().Trim();
                                    progressBar1.Value = j * progressBar1.Maximum / transcount;
                                    lcAcct = Convert.ToString(intAcctView.Rows[m]["cacctnumb"]);
                                    lnBookBal = Convert.ToDecimal(intAcctView.Rows[m]["nbookbal"]);
                                    maskedTextBox1.Text = lcAcct;
                                    textBox5.Text = Convert.ToString(intAcctView.Rows[m]["cacctname"]).Trim();
                                    textBox4.Text = lnBookBal.ToString("N2");
                                    sqlString1 = "select cacctnumb,ntranamnt,dtrandate,itemid, cstack from tranhist where cacctnumb = " + "'" + lcAcct + "'" + " order by itemid desc";
                                    SqlDataAdapter dan = new SqlDataAdapter(sqlString1, ndConnHandle);
                                    DataTable balview = new DataTable();
                                    dan.Fill(balview);
                                    if (balview.Rows.Count > 0)
                                    {
                                        indCount = balview.Rows.Count;
                                        for (int l = 0; l < indCount; l++)
                                        {
                                            lnItemid = Convert.ToInt32(balview.Rows[l]["itemid"]);
                                            lnTranAmt = Convert.ToDecimal(balview.Rows[l]["ntranamnt"]);
                                            ldTranDate = Convert.ToDateTime(balview.Rows[l]["dtrandate"]);
                                            updateTrans(lcAcct, lnBookBal, lnItemid);
                                            //                                            udb.updDayBal(cs, ldTranDate, lcAcct, lnTranAmt, globalvar.gnBranchid, ncompid);
                                            lnBookBal = lnBookBal - lnTranAmt;
                                        }
                                    }//else { MessageBox.Show("No transactions found "); }
                                    j++;
                                }
                            }
                            else { MessageBox.Show("No Savings accounts found "); }
                            MessageBox.Show("Savings Accounts Running Balance fixed successfully ");
                        }
                        break;
                }
            }
        }

        //private void updateTrans(string tcuAcctNumb, decimal tnuBkBal, string tcuStack)
        //{
        //    using (SqlConnection ndConnHandle1 = new SqlConnection(cs))
        //    {
        //        string cquery = "update tranhist set nnewbal=@tnBkBal where cacctnumb=@tcAcctNumb and cstack=@lcStack";
        //        SqlDataAdapter cuscommand = new SqlDataAdapter();
        //        cuscommand.UpdateCommand = new SqlCommand(cquery, ndConnHandle1);
        //        cuscommand.UpdateCommand.Parameters.Add("@tnBkBal", SqlDbType.Decimal).Value = tnuBkBal;
        //        cuscommand.UpdateCommand.Parameters.Add("@tcAcctNumb", SqlDbType.VarChar).Value = tcuAcctNumb;
        //        cuscommand.UpdateCommand.Parameters.Add("@lcStack", SqlDbType.VarChar).Value = tcuStack;

        //        ndConnHandle1.Open();
        //        cuscommand.UpdateCommand.ExecuteNonQuery();
        //        textBox6.Text = tnuBkBal.ToString("N2");
        //        ndConnHandle1.Close();
        //    }
        //}

        private void updateTrans(string tcuAcctNumb, decimal tnuBkBal, int tnItemID)
        {
            using (SqlConnection ndConnHandle1 = new SqlConnection(cs))
            {
                string lcAcct = string.Empty;

                string cquery = "update tranhist set nnewbal=@tnBkBal where cacctnumb=@tcAcctNumb and itemid=@lnItemID";
                SqlDataAdapter cuscommand = new SqlDataAdapter();
                cuscommand.UpdateCommand = new SqlCommand(cquery, ndConnHandle1);
                cuscommand.UpdateCommand.Parameters.Add("@tnBkBal", SqlDbType.Decimal).Value = tnuBkBal;
                cuscommand.UpdateCommand.Parameters.Add("@tcAcctNumb", SqlDbType.VarChar).Value = tcuAcctNumb;
                cuscommand.UpdateCommand.Parameters.Add("@lnItemID", SqlDbType.Int).Value = tnItemID;

                ndConnHandle1.Open();
                cuscommand.UpdateCommand.ExecuteNonQuery();
                textBox6.Text = tnuBkBal.ToString("N2");
                ndConnHandle1.Close();
            }
        }


        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            maskedTextBox1.Enabled = radioButton1.Checked ? true : false;
            radioButton3.Enabled = radioButton4.Enabled = radioButton5.Enabled = radioButton6.Enabled = radioButton1.Checked ? false : true;
        }

        private void maskedTextBox1_Validated(object sender, EventArgs e)
        {
            string tcAcctNumb = maskedTextBox1.Text.Trim();
            string sqlString = "select cacctname,nbookbal from glmast where cacctnumb  = " + tcAcctNumb;
            DataTable indview = new DataTable();

            using (SqlConnection ndConnHandle = new SqlConnection(cs))
            {
                ndConnHandle.Open();
                SqlDataAdapter da1 = new SqlDataAdapter(sqlString, ndConnHandle);
                da1.Fill(indview);
                if (indview != null && indview.Rows.Count > 0)
                {
                    textBox4.Text = indview.Rows[0]["nbookbal"].ToString();
                    textBox5.Text = indview.Rows[0]["cacctname"].ToString();
                    getRunBal(tcAcctNumb);
                }
                else
                { MessageBox.Show("account could not be found"); maskedTextBox1.Text = ""; }
            }
        }



        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            maskedTextBox1.Enabled = radioButton1.Checked ? true : false;
            radioButton3.Enabled = radioButton4.Enabled = radioButton5.Enabled = radioButton6.Enabled = radioButton2.Checked ? true : false;

            //bool llSelectOk = radioButton3.Checked || radioButton4.Checked || radioButton5.Checked || radioButton6.Checked ? true : false;
            //if (radioButton2.Checked && llSelectOk)
            //{
            //    maskedTextBox1.Enabled = false;
            //    maskedTextBox1.Text = "";                     
            //    saveButton.Enabled = true;
            //    saveButton.BackColor = Color.LawnGreen;
            //    saveButton.Select();
            //}
            //else
            //{
            //    saveButton.Enabled = false;
            //    saveButton.BackColor = Color.Gainsboro;
            //}
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                maskedTextBox1.Enabled = false;
                maskedTextBox1.Text = "";
                saveButton.Enabled = true;
                saveButton.BackColor = Color.LawnGreen;
                saveButton.Select();
            }
            else
            {
                saveButton.Enabled = false;
                saveButton.BackColor = Color.Gainsboro;
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            {
                //maskedTextBox1.Enabled = false;
                //maskedTextBox1.Text = "";
                saveButton.Enabled = true;
                saveButton.BackColor = Color.LawnGreen;
                saveButton.Select();
            }
            else
            {
                saveButton.Enabled = false;
                saveButton.BackColor = Color.Gainsboro;
            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked)
            {
                maskedTextBox1.Enabled = false;
                maskedTextBox1.Text = "";
                saveButton.Enabled = true;
                saveButton.BackColor = Color.LawnGreen;
                saveButton.Select();
            }
            else
            {
                saveButton.Enabled = false;
                saveButton.BackColor = Color.Gainsboro;
            }

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void radioButton3_CheckedChanged_1(object sender, EventArgs e)
        {
            glMultipleSelection = radioButton3.Checked ? true : false;
            AllClear2Go();
        }

        private void radioButton4_CheckedChanged_1(object sender, EventArgs e)
        {
            glMultipleSelection = radioButton4.Checked ? true : false;
            AllClear2Go();
        }

        private void radioButton5_CheckedChanged_1(object sender, EventArgs e)
        {
            glMultipleSelection = radioButton5.Checked ? true : false;
            AllClear2Go();
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            glMultipleSelection = radioButton6.Checked ? true : false;
            AllClear2Go();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            acctEnquiry ae = new TclassLibrary.acctEnquiry(cs, ncompid, dloca);
            ae.ShowDialog();
        }
    }
}
